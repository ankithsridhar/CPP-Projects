#include "event.h"

using namespace std;
/*********************************************************************
 ** Function: event
 ** Description: epmty constructor
 ** Parameters: none
 *********************************************************************/
Event::Event(){
    
}
