#include "hand.h"


	Hand::Hand(){
		this->n_cards = 0;
		this->cards = NULL;
	}

	int Hand::getn_cards(){
		return n_cards;
	}

	Card* Hand::getCards() {
		return cards;
	}

	int Hand::inHand(int temp) {
	//for loop for player number of cards 
	int counter = 0;
	for (int i=0; i<n_cards; i++){
		if (temp == cards[i].getRank()) {
			//RETURN TRUE
			counter ++;
		}
		// else {
		// 	//RETURN FALSE
		// 	counter;

		// 	//you dont have that card. go again
		// 	//repeat player turn.
		// }
	}
	return counter;
	}

	Card Hand::deleteCard(string temp){
		//allocate a new array of Card objects with the size + 1
		Card* new_arr = new Card [this->n_cards - 1];
		bool cardFound = false;

		//copy all objects from the old array (cards) into the new array
		int counter= 0;

		Card t;

		for (int i = 0; i < this->n_cards; ++i)
		{
			if ((cardFound) or (this->cards[i].getRank() != cards[i].stringConvert(temp))) {
				new_arr[counter] = this->cards[i]; // AOO of Card 
				counter++;
			} else {
				t = this->cards[i];
				cardFound = true;
			}
		}

		//free the cards array (old array)
		if (this->cards != NULL){
			delete [] this->cards;
		}
		//set cards array to the new array
		this->cards = new_arr;

		this->n_cards--;

		return t;

	}

	Card Hand::deleteBook(int rank){
		//allocate a new array of Card objects with the size + 1
		Card* new_arr = new Card [this->n_cards -1];
		bool cardFound = false;

		//copy all objects from the old array (cards) into the new array
		int counter= 0;

		Card t;

		for (int i = 0; i < this->n_cards; ++i)
		{
			if ((cardFound) or (this->cards[i].getRank() != rank)) {
				new_arr[counter] = this->cards[i]; // AOO of Card 
				counter++;
			} else {
				t = this->cards[i];
				cardFound = true;
			}
		}

		//free the cards array (old array)
		if (this->cards != NULL){
			delete [] this->cards;
		}
		//set cards array to the new array
		this->cards = new_arr;

		this->n_cards--;

		return t;

	}


	Hand::~Hand() {
		if (this->cards != NULL){
			delete [] this->cards;
			this->cards = NULL;
		}
	}

	void Hand::addCard(Card& c){
		//allocate a new array of Card objects with the size + 1
		Card* new_arr = new Card [this->n_cards + 1];

		//copy all objects from the old array (cards) into the new array
		for (int i = 0; i < this->n_cards; ++i)
		{
			new_arr[i] = this->cards[i]; // AOO of Card 
		}

		//add the new Card object c into index n_cards
		new_arr[this->n_cards] = c;

		//free the cards array (old array)
		if (this->cards != NULL)
			delete [] this->cards;

		//set cards array to the new array
		this->cards = new_arr;

		//increment the n_cards
		this->n_cards++;
	}