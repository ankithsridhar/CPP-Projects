#include "player.h"
#include <iostream>

	Player::Player(){
		this->books = new int[13];
		n_books = 0;
	}
	Hand& Player::getHand(){
  		return hand;
	}

	int Player::getNumBooks(){
		return n_books;
	}

	void Player::setNumBooks(int n){
		this->n_books = n;
	}

	int Player::getNumCards(){
		return hand.getn_cards();
	}

	void Player::goFish(Card &go) {
		this->hand.addCard(go);
	}
	// Card removeRank(int temp){
	// 	return hand.retCard(temp);
	// }

	void Player::addBook(int j){
		int* new_arr = new int [this->n_books + 1];

		//copy all objects from the old array (cards) into the new array
		for (int i = 0; i < this->n_books; ++i)
		{
			new_arr[i] = this->books[i]; // AOO of Card 
		}

		//add the new Card object c into index n_cards
		new_arr[this->n_books] = j;

		//free the cards array (old array)
		if (this->books != NULL)
			delete [] this->books;

		//set cards array to the new array
		this->books = new_arr;

		//increment the n_cards
		this->n_books++;

	}


	void Player::checkForBooks(){
		//looping though the hand
		for (int i = 0; i < 13; i++)
		{
			if(hand.inHand(i) == 4){
				hand.deleteBook(i);
				hand.deleteBook(i);
				hand.deleteBook(i);
				hand.deleteBook(i);
				addBook(i);
			}
		}
		
		//if there is 4 of a kind of one suit
		//then, add 1 to the book counter
		//delete the 4 of a kind from the players/ computers hand


	}

	void Player::print_books(){
		for (int i = 0; i < n_books; i++)
		{
			cout << books [i] + 2 << ", ";
		}

		cout << endl;
	}


	void Player::place_a_card(Card& c){
		this->hand.addCard(c);
	}