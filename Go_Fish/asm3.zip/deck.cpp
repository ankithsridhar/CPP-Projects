#include "deck.h"
#include <iostream>

using namespace std;


// must have constructors, destructor, accessors, and mutators
	Deck::Deck(){
		this->n_cards = 52;
		for (int i = 0; i < this->n_cards; ++i)
		{
			this->cards[i].setRank(i%13);
			this->cards[i].setSuit(i/13);
		}
	}

	int Deck::getDeckCards(){
		return n_cards;
	}

	void Deck::shuffleDeck(){
		int temp = 0;
		int randomIndex = 0;
		srand(time(NULL));
		for(int i = 0; i < n_cards; i++){
			int card1 = rand() % 52;
			int card2 = rand() % 52;
			Card temp = cards[card1];
			cards[card1] = cards[card2];
			cards[card2] = temp;
		}

	}

	Card& Deck::remove_card(){
		this->n_cards --;
		return this->cards[this->n_cards];
	}
